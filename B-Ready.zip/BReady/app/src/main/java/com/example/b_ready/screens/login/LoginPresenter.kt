package app.kotlin.bready.screens.login

import app.kotlin.bready.app.CustomApp
import app.kotlin.punona.screens.login.LoginContract

class LoginPresenter(private val view: LoginContract.View,private val app: CustomApp) : LoginContract.Presenter {

    override fun validateCredentials(mobile: String, pword: String) {
        if (mobile.isEmpty() || pword.isEmpty()) {
            view.showEmptyMessage()
            return
        }

        val savedUser = app.getUser()
        if (mobile == savedUser.mobileNumber && pword == savedUser.password) {
            view.showSuccessMessage()
            view.showDashboardScreen()
        } else {
            view.showInvalidCredential()
        }
    }
}