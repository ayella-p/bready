package app.kotlin.bready.data

data class User(
    val mobileNumber: String,
    val password: String
)