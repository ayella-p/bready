package app.kotlin.bready.screens.login

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import app.kotlin.bready.app.CustomApp
import app.kotlin.bready.utils.getEditTextValue
import app.kotlin.bready.utils.toast
import app.kotlin.punona.screens.login.LoginContract
import com.example.b_ready.R

class LoginActivity : Activity(), LoginContract.View {

    private lateinit var presenter: LoginPresenter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        presenter = LoginPresenter(this, application as CustomApp)

        findViewById<Button>(R.id.btnSignIn).setOnClickListener {
            val mobileInput = getEditTextValue(R.id.etMobileNumber)
            val passwordInput = getEditTextValue(R.id.etPassword)

            presenter.validateCredentials(mobileInput, passwordInput)
        }
    }

    override fun showEmptyMessage() {
        toast("Please enter your mobile number and password")
    }

    override fun showSuccessMessage() {
        toast("Welcome back to B-Ready!")
    }

    override fun showInvalidCredential() {
        toast("Invalid Mobile Number or Password")
    }

    override fun showDashboardScreen() {
        // Uncomment this once your Dashboard is ready
        // val intent = Intent(this, DashboardActivity::class.java)
        // startActivity(intent)
        // finish() // Destroy the login screen so the user can't press 'back' to return to it
    }
}